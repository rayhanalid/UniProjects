package com.PATCH.PetDatingApp.dto;

public class ProfileResponse {
    private String uid;
    private String pid;

    // Add getters and setters for the fields

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }
}
