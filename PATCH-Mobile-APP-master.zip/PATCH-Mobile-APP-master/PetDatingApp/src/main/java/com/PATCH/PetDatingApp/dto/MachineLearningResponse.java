package com.PATCH.PetDatingApp.dto;

import java.util.List;
import java.util.Map;

public class MachineLearningResponse {
    private List<ProfileData> profiles;

    public List<ProfileData> getProfiles() {
        return profiles;
    }

    public void setProfiles(List<ProfileData> profiles) {
        this.profiles = profiles;
    }
}
